class APIConfig:
    token: str = None
    url: str = None
